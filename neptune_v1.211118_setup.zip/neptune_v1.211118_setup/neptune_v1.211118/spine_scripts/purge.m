clear; close all hidden;

poolobj = gcp('nocreate'); % delete pool if it exists
if ~isempty(poolobj)
    delete(gcp);
end
clear all; close all; clc;
