function scfMRItb_03_reslice_func(base_dir_sub, fname, S_anat)

% If slice thickness is different between anatomical and functional, then
%  the functional will be resliced to the slice thickness of the anatomical.
%  This is necessary for the toolbox to function as intended

scfMRItb_04_unzipFile(base_dir_sub, fname, '')
F = load_untouch_nii([base_dir_sub fname '.nii']);
dx = F.hdr.dime.pixdim(2);
dy = F.hdr.dime.pixdim(3);
dz = S_anat;
fname_resliced = [fname '_resliced'];

unix(['3dresample -dxyz ' num2str(dx) ' ' num2str(dy) ' ' num2str(dz) ' -prefix ' base_dir_sub fname_resliced '.nii' ' -input ' base_dir_sub fname '.nii'])

movefile([base_dir_sub fname '.nii'],[base_dir_sub fname '_beforeReslice_ORIGINAL' '.nii'],'f')
unix(['rm -f ' base_dir_sub fname '.nii']);
movefile([base_dir_sub fname '_resliced' '.nii'],[base_dir_sub fname '.nii'],'f')

end
