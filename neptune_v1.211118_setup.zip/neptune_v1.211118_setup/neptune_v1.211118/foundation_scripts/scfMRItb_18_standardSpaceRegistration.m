function scfMRItb_18_standardSpaceRegistration(base_dir_sub,fname,fname_anat_orig, varargin)


% Patrons, we are sorry that co-registration to PAM50 standard space has not
% been developed yet (that doesn't necessarily mean that we will have the
% functionality in the future).

% If you want to perform analyses in standard space, here is what we suggest:
% (1) Perform pre-processing in Neptune as usual.
% (2) Co-register the anatomical to PAM50 space in Spinal Cord Toolbox (SCT).
% (3) In any MRI software, use the transformation matrix to transform the fully 
%     pre-processed fMRI data to PAM50 space (note that functional to anatomical 
%     registration need not be done again as Neptune would have already done it in step-11.)
% (4) If you want to use the mask of cord quadrants, transform that to the PAM50 space as well.
% (5) You can always import the transformed fMRI data to Neptune for post-processing.

% Example scenario: perform task fMRI activation analysis - here is an example pipeline:
% (1) Pre-process data in Neptune (all steps as usual).
% (2) Co-register the anatomical to PAM50 space in Spinal Cord Toolbox (SCT).
% (3) In FSL, apply the transformation matrix to the fMRI data as well as the spine mask (*_mask_SC.nii.gz)
% (4) Perform GLM activation second-level statistical analysis in FSL using the transformed data and the mask.
% A similar pipeline can be adopted for ICA-based analyses, for example, using a software of your choice


end