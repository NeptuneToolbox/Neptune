function scan_sync = phys_filt_sync_ricor(current_file_phys, channel, vat, dynamics)

% Original version (with comments) written by John Sexton
% 2010-03-01 Modified and debugged by Robert L. Barry

%**************************************************************************
% This function displays the frequency components of the physiological
% log file, revealing frequency components of heartrate and respiration.
%**************************************************************************

%**************************************************************************
% Read the prescribed channels of the physlog
%**************************************************************************

channels = 1:10;            % Total channels = 1:10; Cardiac = 5; Resp = 6; 

phys_out_allchan = read_physlog_file(current_file_phys, channels);

phys_out = phys_out_allchan(:,channel)';       % Transpose to row vector

%**************************************************************************
% Here we indentify the portion of the dynamic image data from the 
% scanner that lines up with the phys log data.  The physlog starts
% recording at the beginning of the preparation pulses and continues until
% the scan is done.  Because some scans are started automatically and
% others are started manually (with a variable amount of time between the
% preparaton pulses and the actual start of the scan), it is necessary to
% start at the end of the phys log and work backwards to find the
% correct timing.
%
% The physlog data is sampled at 500 Hz, or 500 times per second.  Thus,
% the time between each physlog sample is 0.002 seconds, or 2 miliseconds
%**************************************************************************

fs_phys = 500;

%**************************************************************************
% Find the end scan marker(s) in the physlog.  The marker is '20' in the
% physlog in hexidecimal format.  The physlog is read in as decimal, so we
% look for the marker 32.  (20 = hex(32)).
%
% The Mark channel in the phys log is channel 10, so we search there:
%**************************************************************************

scan_end_indices = find(phys_out_allchan(:,10) > 31);

%**************************************************************************
% For reasons unknown, sometimes there is more than one stop marker.
% We only care about the last one:
%**************************************************************************

scan_end = scan_end_indices(end);

%**************************************************************************
% We know the length of one repetition time and the end of the physlog
% scan.  So now we can step back any number of dynamic scans to find where
% in the physlog corresponds to the beginning of the collection of MRI
% data.  ONE TR Corresponds to ONE Dynamic Scan
%**************************************************************************

phys_samples_for_one_volume = vat * fs_phys;

%**************************************************************************
% Now that we know the number of physlog samples in one TR, and how many
% TRs in the scan, we can determine the number of physlog samples in the
% scan:
%**************************************************************************

phys_samples_total_scan = floor(dynamics * phys_samples_for_one_volume);

%**************************************************************************
% Now we can start at the scan end marker in the physlog and backtrack by
% the amount of physlog samples in the total scan to find where the physlog
% data syncs up with the MRI scan.
%**************************************************************************

scan_start = scan_end - phys_samples_total_scan;

%**************************************************************************
% Find the synchronized data
%**************************************************************************

scan_sync = phys_out(scan_start+1:scan_end);
