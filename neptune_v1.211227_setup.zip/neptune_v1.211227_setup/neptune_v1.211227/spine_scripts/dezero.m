function junk = dezero(F)

junk = sort(unique(F(:)));
junk = junk(2:end);

end