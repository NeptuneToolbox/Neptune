function T = evalc_parfor(str)

T = evalc('unix(str)');

end
