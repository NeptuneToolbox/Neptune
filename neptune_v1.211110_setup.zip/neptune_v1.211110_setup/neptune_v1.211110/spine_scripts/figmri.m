function figmri(img)

img = squeeze(img);

if size(img,3) > 1
    img = img(:,:,1);
    disp('Only showing first slice of 3D volume.');
end
imshow(single(abs(img)), [], 'InitialMagnification', 'fit');
colorbar;
