function save_parfor(str, temp)

eval(['save ' str ' temp;']);

end
