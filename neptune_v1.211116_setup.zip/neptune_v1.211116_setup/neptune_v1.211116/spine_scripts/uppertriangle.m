function ut = uppertriangle(mat)

ut = mat(find(triu(ones(size(mat)),1)==1));

end
