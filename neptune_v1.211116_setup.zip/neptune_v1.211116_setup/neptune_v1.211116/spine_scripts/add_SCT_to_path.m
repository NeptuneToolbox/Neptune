% 2019-04-11
% Robert L. Barry

% is the path to SCT already set?
[sctnotfound, unixoutput] = unix('sct_deepseg_sc');
if sctnotfound
    setenv('PATH', [getenv('PATH') ':/Applications/SCT/ver_curr/bin']);
    disp(sprintf(['Adding SCT to Matlab''s path.']));
end
clear sctnotfound unixoutput;
