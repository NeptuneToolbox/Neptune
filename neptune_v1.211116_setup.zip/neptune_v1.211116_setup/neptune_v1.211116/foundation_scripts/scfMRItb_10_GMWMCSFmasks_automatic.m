function scfMRItb_10_GMWMCSFmasks_automatic(base_dir_sub,fname,fname_anat_orig, varargin)

% Patrons, we are sorry that automation of the GM/WM/CSF masks step has not
% been developed yet (that doesn't necessarily mean that we will have the
% functionality in the future).



% ----- DEFINE GM / WM / CSF MASKS ----------------------------------------



% ----- CREATE MASKS FOR ANATOMICAL & FUNCTIONALS -------------------------



% ----- SAVE MASKS FOR ANATOMICAL & FUNCTIONALS ---------------------------
% save affine_reg_mask and funct_mask



end